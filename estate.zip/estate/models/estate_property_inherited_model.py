from odoo import models, fields

class EstatePropertyInherited(models.Model):
    _inherit = 'estate.property'

    extra_feature = fields.Char(string="Caractéristique supplémentaire")
    new_price = fields.Float(string="Prix modifié")
