from odoo import models, fields

class EstatePropertyType(models.Model):
    _name = 'estate.property.type'
    _description = 'Type de propriété'
    _order = 'name'
    _sql_constraints = [
        ('unique_type_name', 'UNIQUE(name)', 'Le nom du type de propriété doit être unique.')
    ]

    name = fields.Char(string="Nom", required=True)
    description = fields.Text(string="Description")
