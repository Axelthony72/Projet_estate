from odoo import models, fields

class EstateProperty(models.Model):
    _name = 'estate.property'
    _description = 'Propriété immobilière'

    name = fields.Char(string="Nom", required=True)
    description = fields.Text(string="Description")
    price = fields.Float(string="Prix", required=True)
    state = fields.Selection([
        ('new', 'Nouveau'),
        ('offer_received', 'Offre reçue'),
        ('sold', 'Vendu'),
    ], string="État", default='new')
offer_ids = fields.One2many('estate.property.offer', 'property_id', string="Offres")
type_id = fields.Many2one('estate.property.type', string="Type de propriété")
