from odoo import models, fields, api
from datetime import timedelta

class EstatePropertyOffer(models.Model):
    _name = 'estate.property.offer'
    _description = 'Offres pour les propriétés immobilières'
    _order = 'price desc'

    price = fields.Float(string="Prix de l'offre", required=True)
    status = fields.Selection([
        ('accepted', 'Acceptée'),
        ('refused', 'Refusée')
    ], string="Statut", copy=False)

    partner_id = fields.Many2one('res.partner', string="Acheteur", required=True)
    property_id = fields.Many2one('estate.property', string="Propriété", required=True, ondelete='cascade')
    validity = fields.Integer(string="Validité (jours)", default=7)
    date_deadline = fields.Date(string="Date limite", compute="_compute_date_deadline", inverse="_inverse_date_deadline")

    @api.depends('validity')
    def _compute_date_deadline(self):
        for offer in self:
            offer.date_deadline = fields.Date.today() + timedelta(days=offer.validity)

    def _inverse_date_deadline(self):
        for offer in self:
            if offer.date_deadline:
                delta = (offer.date_deadline - fields.Date.today()).days
                offer.validity = max(delta, 0)
