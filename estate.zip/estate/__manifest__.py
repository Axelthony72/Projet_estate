{
    'name': 'Estate',
    'version': '1.0',
    'summary': 'Gestion des biens immobiliers',
    'author': 'Thony',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/estate_property_views.xml',
    ],
    'installable': True,
    'application': True,
}
